package sobreescrita;
public class Gato extends Animal{
    
    @Override
    public String emiteSom(){
        return "meow meow";
    }
}
