package sobreescrita;
public class Sobreescrita {
    public static void main(String[] args) {
        
        Animal animal1 = new Animal();
        Cachorro luna = new Cachorro();
        Gato fugazza = new Gato();
        Galinha chica = new Galinha();
        
        System.out.println("Som do animal: " + animal1.emiteSom());
        System.out.println("Som do Cachorro: " + luna.emiteSom());
        System.out.println("Som do Gato: " + fugazza.emiteSom());
        System.out.println("Som da Galinha: " + chica.emiteSom());
    }    
}
