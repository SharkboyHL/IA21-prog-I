package sobreescrita;
public class Galinha extends Animal {
    
    @Override
    public String emiteSom(){
        return "có có có";
    }
}
