package sobreescrita;
public class Animal {
    
    public String emiteSom(){
        return "qualquer som";
    }
}
