package diagrama1;
public class Diagrama1 {
    public static void main(String[] args) {

        
    }    
}
