package sobreescrita;
public class Cachorro extends Animal{
    
    @Override
    public String emiteSom(){
        return "auf auf";
    }
}
