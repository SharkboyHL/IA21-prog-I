package diagrama1;
import java.util.Scanner;
public class Diagrama1 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        
        System.out.println("Cadastrando Empregado...");
        System.out.print("\nInsira o seu nome: ");
        String nome = teclado.nextLine();
        System.out.print("Insira o seu E-mail: ");
        String email = teclado.nextLine();
        System.out.print("Insira o seu salário (Empregado): ");
        double salario = teclado.nextDouble();
        
        System.out.println("\nCadastrando Chefe...");
        System.out.print("Insira o seu nome: ");
        String nomeChefe = teclado.nextLine();
        System.out.print("Insira o seu E-mail: ");
        String emailChefe = teclado.nextLine();
        System.out.print("Insira o seu Salário (Chefe): ");
        double salarioChefe = teclado.nextDouble();
        System.out.print("Insira o seu benefício: ");
        double beneficio = teclado.nextDouble();
        
        System.out.println("\nCadastrando Estágiario...");
        
        
        Empregado worker = new Empregado(1, nome, email, salario);
        Chefe boss = new Chefe(1, nomeChefe, emailChefe, salarioChefe, beneficio);
        Estagiario junior = new Estagiario(1, "Lucas", "lucas@gmail.com", 1400, 40);
        
        System.out.println("O salário do Empregado antes do aumento: R$" + worker.getSalario());
        System.out.println("O salário do Empregado depois do aumento: R$" + worker.aumentoSalario(20)); 
        System.out.println("===================================================================");
        System.out.println("O salário do Chefe antes do aumento: R$" + boss.getSalario());
        System.out.println("O salário do Chefe depois do aumento e de seus benefícios: R$" + boss.aumentoSalarial(10));
        System.out.println("===================================================================");
        System.out.println("O salário do Estágiario antes do aumento e dos descontos descontos: R$" + junior.getSalario());
        System.out.println("O salário do Estágiario depois do aumento e dos descontos: R$" + junior.aumentoSalarial(30));
    }    
}
