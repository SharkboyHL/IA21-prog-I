package sobrecarga;
public class Sobrecarga {
    public static void main(String[] args) {
        
        Passagem p1 = new Passagem();
        System.out.println("O valor da passagem sem seguro é: R$" + p1.calcularPreco(100, 10));
        System.out.println("O valor da passagem com seguro é: R$" + p1.calcularPreco(100, 10, 20));
    }    
}
