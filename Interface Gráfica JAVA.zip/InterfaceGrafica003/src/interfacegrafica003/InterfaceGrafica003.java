package interfacegrafica003;

import javax.swing.JFrame;

public class InterfaceGrafica003 {
    public static void main(String[] args) {

        JFrame window = new Janela();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
    }    
}
