// Dupla: Airam & Henrique

package interfacegrafica001;

import javax.swing.JFrame;

public class InterfaceGrafica001 {

    public static void main(String[] args) {

        JFrame window = new Janela();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
    }
}
